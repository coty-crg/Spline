var searchData=
[
  ['linear_20',['Linear',['../_spline_8cs.html#a3c7eadfa13047b10bfba05f390a6e135a32a843da6ea40ab3b17a3421ccdf671b',1,'Spline.cs']]]
];
