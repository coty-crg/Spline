var class_doxygen_config =
[
    [ "DocDirectory", "class_doxygen_config.html#aea9ba41fe61487effafbeb77120749f0", null ],
    [ "PathtoDoxygen", "class_doxygen_config.html#ad308ed1d0bdb202587fba232b754929f", null ],
    [ "Project", "class_doxygen_config.html#ae69318495ba1db9f3a4d88e01764f9b4", null ],
    [ "ScriptsDirectory", "class_doxygen_config.html#aea53b2e7fc0f47a7f658ce25e65c4a09", null ],
    [ "Synopsis", "class_doxygen_config.html#a2b1926144ba2768c36de32a8d3445567", null ],
    [ "Version", "class_doxygen_config.html#af72cbcc553de9766a100f77f90c35626", null ]
];