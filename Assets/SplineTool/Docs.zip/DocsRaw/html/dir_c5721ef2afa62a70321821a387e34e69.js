var dir_c5721ef2afa62a70321821a387e34e69 =
[
    [ "DoxygenWindow.cs", "_doxygen_window_8cs.html", [
      [ "DoxygenConfig", "class_doxygen_config.html", "class_doxygen_config" ],
      [ "DoxygenWindow", "class_doxygen_window.html", "class_doxygen_window" ],
      [ "DoxyRunner", "class_doxy_runner.html", "class_doxy_runner" ],
      [ "DoxyThreadSafeOutput", "class_doxy_thread_safe_output.html", "class_doxy_thread_safe_output" ]
    ] ]
];