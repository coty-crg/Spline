﻿

#if UNITY_EDITOR && DREAMTECK_SPLINES
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class reference_tester : MonoBehaviour
{
    public Dreamteck.Splines.SplineComputer reference;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
#endif